<?php

// =========================================== //
//            Post Type: Portfolio             //
// =========================================== //

function tmq_portfolio_init() {
  $labels = array(
    'name' 				 	=> __('Portfolio', 'vertikal_plugin'),
    'singular_name'		 	=> __('Portfolio', 'vertikal_plugin'),
    'menu_name' 			=> __('Portfolio', 'vertikal_plugin'),
    'all_items'				=> __('All Portfolio Items', 'vertikal_plugin'),
    'add_new' 				=> __('Add New', 'vertikal_plugin'),
    'add_new_item' 			=> __('Add New Item', 'vertikal_plugin'),
    'edit_item' 			=> __('Edit Item', 'vertikal_plugin'),
    'new_item' 				=> __('New Portfolio Item', 'vertikal_plugin'),
    'view_item' 			=> __('View Item', 'vertikal_plugin'),
    'search_items'			=> __('Search Portfolio', 'vertikal_plugin'),
    'not_found'    			=> __('No portfolio items found', 'vertikal_plugin'),
    'not_found_in_trash'    => __('No portfolio items found in Trash', 'vertikal_plugin'), 
    'parent_item_colon'     => ''
  );

  $args = array(
    'labels' 				=> $labels,
	'description'			=> __('Add Portfolio post type. This post type can be used to show portfolio or projects.', 'vertikal_plugin'),
    'public' 				=> true,
	'exclude_from_search'	=> false,
    'publicly_queryable' 	=> true,
    'show_ui' 				=> true, 
    'show_in_nav_menu' 		=> true, 
    'show_in_menu' 			=> true, 
    'show_in_admin_bar' 	=> false,
    'menu_position'		 	=> null,
    'capability_type' 		=> 'post',
	'menu_icon'				=> null,
    'query_var' 			=> true,
    'rewrite' 				=> array( 'slug' => 'portfolio' ),
    'has_archive' 			=> false, 
    'hierarchical' 			=> true,
	'taxonomies' 			=> array('post_tag'),	
	'can_export'			=> true,
    'supports' 				=> array( 'title', 'thumbnail', 'excerpt', 'editor', 'comments', 'post-formats' )
  ); 

  register_post_type( 'tmq-portfolio', $args );
  
  // Fix Rewrite rule for some WP versions - Usable for pagination 
  add_rewrite_rule( 'portfolio/page/([0-9]+)/?$', 'index.php?pagename=portfolio&paged=$matches[1]', 'top' );

  register_taxonomy('portfolio_category',
		array('tmq-portfolio'), 
		array(
			'label' 			=> __('Portfolio Categories', 'vertikal_plugin'),
			'singular_label' 	=> __('Portfolio Categories', 'vertikal_plugin'),
			'rewrite' 			=> true,
			'show_admin_column'	=> true,
			'show_ui'			=> true,
			'hierarchical' 		=> true,
			'query_var' 		=> true
		)
	);  

}
add_action( 'init', 'tmq_portfolio_init' );

//Change Title of Item
function change_portfolio_title( $title ){
     $screen = get_current_screen();
     if  ( 'tmq-portfolio' == $screen->post_type ) {
          $title = __('Enter project title here', 'vertikal_plugin');
     }
     return $title;
}
add_filter( 'enter_title_here', 'change_portfolio_title' );


// =========================================== //
//           Post Type: TEAM MEMBERS           //
// =========================================== //

function tmq_team_init() {
  $labels = array(
    'name' 				 	=> __('Team Members', 'vertikal_plugin'),
    'singular_name'		 	=> __('Member', 'vertikal_plugin'),
    'menu_name' 			=> __('Team Members', 'vertikal_plugin'),
    'all_items'				=> __('All Members', 'vertikal_plugin'),
    'add_new' 				=> __('Add New', 'vertikal_plugin'),
    'add_new_item' 			=> __('Add New Member', 'vertikal_plugin'),
    'edit_item' 			=> __('Edit Member', 'vertikal_plugin'),
    'new_item' 				=> __('New Member', 'vertikal_plugin'),
    'view_item' 			=> __('View Member', 'vertikal_plugin'),
    'search_items'			=> __('Search Members', 'vertikal_plugin'),
    'not_found'    			=> __('No members found', 'vertikal_plugin'),
    'not_found_in_trash'    => __('No members found in Trash', 'vertikal_plugin'), 
    'parent_item_colon'     => ''
  );

  $args = array(
    'labels' 				=> $labels,
	'description'			=> __('Add team members. You can show members in Themique ShortCode Manager later.', 'vertikal_plugin'),
    'public' 				=> true,
	'exclude_from_search'	=> true,
    'publicly_queryable' 	=> true,
    'show_ui' 				=> true, 
    'show_in_nav_menu' 		=> false, 
    'show_in_menu' 			=> true, 
    'show_in_admin_bar' 	=> false,
    'menu_position'		 	=> null,
    'capability_type' 		=> 'post',
	'menu_icon'				=> null,
    'query_var' 			=> true,
    'rewrite' 				=> array( 'slug' => 'members' ),
    'has_archive' 			=> false, 
    'hierarchical' 			=> false,
	'can_export'			=> true,
    'supports' 				=> array( 'title', 'thumbnail', 'page-attributes')
  ); 

  register_post_type( 'team-members', $args );
  
  register_taxonomy('department',
		array('team-members'), 
		array(
			'label' 			=> __('Departments', 'vertikal_plugin'),
			'singular_label' 	=> __('Departments', 'vertikal_plugin'),
			'rewrite' 			=> true,
			'show_admin_column'	=> true,
			'show_ui'			=> true,
			'hierarchical' 		=> true,
			'query_var' 		=> true
		)
	);   
}
add_action( 'init', 'tmq_team_init' );

//Change Title Name to Member Name
function change_team_members_title( $title ){
     $screen = get_current_screen();
     if  ( 'team-members' == $screen->post_type ) {
          $title = __('Enter member name here', 'vertikal_plugin');
     }
     return $title;
}
add_filter( 'enter_title_here', 'change_team_members_title' );


// =========================================== //
//      Post Type: Magic Widget Post Type      //
// =========================================== //

function tmq_magic_widget_init() {
  $labels = array(
    'name' 				 	=> __('Magic Widgets', 'vertikal_plugin'),
    'singular_name'		 	=> __('Magic Widget', 'vertikal_plugin'),
    'menu_name' 			=> __('Magic Widgets', 'vertikal_plugin'),
    'all_items'				=> __('All Widgets', 'vertikal_plugin'),
    'add_new' 				=> __('Add New', 'vertikal_plugin'),
    'add_new_item' 			=> __('Add New Magic Widget', 'vertikal_plugin'),
    'edit_item' 			=> __('Edit Magic Widget', 'vertikal_plugin'),
    'new_item' 				=> __('New Magic Widget', 'vertikal_plugin'),
    'view_item' 			=> __('View Magic Widget', 'vertikal_plugin'),
    'search_items'			=> __('Search Magic Widgets', 'vertikal_plugin'),
    'not_found'    			=> __('No magic widgets found', 'vertikal_plugin'),
    'not_found_in_trash'    => __('No magic widgets found in Trash', 'vertikal_plugin'), 
    'parent_item_colon'     => ''
  );

  $args = array(
    'labels' 				=> $labels,
	'description'			=> __('Add Magic widget post type. This post type can be use in sidebars as an all in one widget.', 'vertikal_plugin'),
    'public' 				=> true,
	'exclude_from_search'	=> true,
    'publicly_queryable' 	=> true,
    'show_ui' 				=> true, 
    'show_in_nav_menu' 		=> false, 
    'show_in_menu' 			=> true, 
    'show_in_admin_bar' 	=> false,
    'menu_position'		 	=> null,
    'capability_type' 		=> 'post',
	'menu_icon'				=> null,
    'query_var' 			=> true,
    'rewrite' 				=> array( 'slug' => 'magic-widget' ),
    'has_archive' 			=> false, 
    'hierarchical' 			=> false,
	'can_export'			=> true,
    'supports' 				=> array( 'title', 'editor' )
  ); 

  register_post_type( 'tmq-magic-widget', $args );
}
add_action( 'init', 'tmq_magic_widget_init' );

//Change Title of Item
function change_magic_title( $title ){
     $screen = get_current_screen();
     if  ( 'tmq-magic-widget' == $screen->post_type ) {
          $title = __('Enter item title here', 'vertikal');
     }
     return $title;
}
add_filter( 'enter_title_here', 'change_magic_title' );


// =========================================== //
//      Post Type: Price Table Post Type       //
// =========================================== //

function tmq_pricetable_init() {
  $labels = array(
    'name' 				 	=> __('Price Tables', 'vertikal_plugin'),
    'singular_name'		 	=> __('Price Table', 'vertikal_plugin'),
    'menu_name' 			=> __('Price Tables', 'vertikal_plugin'),
    'all_items'				=> __('All Price Tables', 'vertikal_plugin'),
    'add_new' 				=> __('Add New', 'vertikal_plugin'),
    'add_new_item' 			=> __('Add New Price Table', 'vertikal_plugin'),
    'edit_item' 			=> __('Edit Price Table', 'vertikal_plugin'),
    'new_item' 				=> __('New Price Table', 'vertikal_plugin'),
    'view_item' 			=> __('View Price Table', 'vertikal_plugin'),
    'search_items'			=> __('Search Price Tables', 'vertikal_plugin'),
    'not_found'    			=> __('No price tables found', 'vertikal_plugin'),
    'not_found_in_trash'    => __('No price tables found in Trash', 'vertikal_plugin'), 
    'parent_item_colon'     => ''
  );

  $args = array(
    'labels' 				=> $labels,
	'description'			=> __('Add Price Table post type. This post type can be use to show packages.', 'vertikal_plugin'),
    'public' 				=> true,
	'exclude_from_search'	=> true,
    'publicly_queryable' 	=> true,
    'show_ui' 				=> true, 
    'show_in_nav_menu' 		=> false, 
    'show_in_menu' 			=> true, 
    'show_in_admin_bar' 	=> false,
    'menu_position'		 	=> null,
    'capability_type' 		=> 'post',
	'menu_icon'				=> null,
    'query_var' 			=> true,
    'rewrite' 				=> array( 'slug' => 'pricetable' ),
    'has_archive' 			=> false, 
    'hierarchical' 			=> false,
	'can_export'			=> true,
    'supports' 				=> array( 'title' )
  ); 

  register_post_type( 'tmq-pricetable', $args );
}
add_action( 'init', 'tmq_pricetable_init' );

//Change Title of Item
function change_pricetable_title( $title ){
     $screen = get_current_screen();
     if  ( 'tmq-pricetable' == $screen->post_type ) {
          $title = __('Enter package title here', 'vertikal_plugin');
     }
     return $title;
}
add_filter( 'enter_title_here', 'change_pricetable_title' );



// =========================================== //
//        Post Type: Clients Post Type         //
// =========================================== //

function tmq_clientspost_init() {
  $labels = array(
    'name' 				 	=> __('Client Groups', 'vertikal_plugin'),
    'singular_name'		 	=> __('Client', 'vertikal_plugin'),
    'menu_name' 			=> __('Clients Carousel', 'vertikal_plugin'),
    'all_items'				=> __('Client Groups', 'vertikal_plugin'),
    'add_new' 				=> __('Add New Group', 'vertikal_plugin'),
    'add_new_item' 			=> __('Add New Client', 'vertikal_plugin'),
    'edit_item' 			=> __('Edit Client', 'vertikal_plugin'),
    'new_item' 				=> __('New Client', 'vertikal_plugin'),
    'view_item' 			=> __('View Client', 'vertikal_plugin'),
    'search_items'			=> __('Search Clients', 'vertikal_plugin'),
    'not_found'    			=> __('No clients found', 'vertikal_plugin'),
    'not_found_in_trash'    => __('No clients found in Trash', 'vertikal_plugin'), 
    'parent_item_colon'     => ''
  );

  $args = array(
    'labels' 				=> $labels,
	'description'			=> __('Add Clients List for Carousel Output.', 'vertikal_plugin'),
    'public' 				=> true,
	'exclude_from_search'	=> true,
    'publicly_queryable' 	=> true,
    'show_ui' 				=> true, 
    'show_in_nav_menu' 		=> false, 
    'show_in_menu' 			=> true, 
    'show_in_admin_bar' 	=> false,
    'menu_position'		 	=> null,
    'capability_type' 		=> 'post',
	'menu_icon'				=> null,
    'query_var' 			=> true,
    'rewrite' 				=> array( 'slug' => 'tmq-clients' ),
    'has_archive' 			=> false, 
    'hierarchical' 			=> false,
	'can_export'			=> true,
    'supports' 				=> array( 'title' )
  ); 

  register_post_type( 'tmq-clients', $args );
}
add_action( 'init', 'tmq_clientspost_init' );

//Change Title of Item
function change_clients_title( $title ){
     $screen = get_current_screen();
     if  ( 'tmq-clients' == $screen->post_type ) {
          $title = __('Enter clients group name here', 'vertikal_plugin');
     }
     return $title;
}
add_filter( 'enter_title_here', 'change_clients_title' );

?>