<?php
// =========================================== //
//		          Magic Widget		           //
// =========================================== //
class themique_power_shortcodes extends WP_Widget {

	function __construct() {
		parent::__construct('tmq-power-shortcodes', $name = ': : Magic Widget : :', array('description' => __('Add Magic Widget Post Content (Tabs, Accordions and more) into Sidebars', 'vertikal_plugin')));
	}

	function widget( $args, $instance ) {
		if ( get_option('embed_autourls') ) {
			$wp_embed = $GLOBALS['wp_embed'];
			add_filter( 'widget_text', array( $wp_embed, 'run_shortcode' ), 8 );
			add_filter( 'widget_text', array( $wp_embed, 'autoembed' ), 8 );
		}
		extract( $args );
		$title = apply_filters( 'widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
		$magicpostid = apply_filters( 'widget_text', $instance['magicpostid'], $instance );
		if( function_exists( 'icl_t' )) {
			$title = icl_t( __('Widgets', 'vertikal_plugin'), 'widget title - ' . md5 ( $title ), $title );
			$magicpostid = icl_t( __('Widgets', 'vertikal_plugin'), 'widget body - ' . $this->id_base . '-' . $this->number, $magicpostid );
		}
		//$magicpostid = do_shortcode( $magicpostid );
		echo $before_widget;
		if ( !empty( $title ) ) { echo $before_title . $title . $after_title; } ?>
		<?php
			$magic_q = get_post( $magicpostid );
				if ( $magic_q ) {
					echo do_shortcode( $magic_q->post_content );
				}
		echo $after_widget;
	}
	
	function update($new_instance, $old_instance) {
		return $new_instance;
	}	
	
	function form($instance) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = strip_tags($instance[ 'title' ]);
		}
		else {
			$title = __( 'New title', 'vertikal_plugin' );
		}
		if ( isset( $instance[ 'magicpostid' ] ) ) {
			$magicpostid = strip_tags($instance[ 'magicpostid' ]);
		}
		else {
			$magicpostid = '';
		}
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'vertikal_plugin')?>: </label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>
		 <p>
			<label for="<?php echo $this->get_field_id('magicpostid'); ?>"><?php _e('Magic Widget', 'vertikal');?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('magicpostid'); ?>" name="<?php echo $this->get_field_name('magicpostid'); ?>">
			 <?php
				$q = new WP_Query(array(
					'post_type'			=> array('tmq-magic-widget'),
					'posts_per_page' 	=> 100						
				));
				while ($q->have_posts()) : $q->the_post();
					if ( $magicpostid == get_the_ID() ) {
						$selected_indicator = ' selected="selected"';
					} else {
						$selected_indicator = '';
					}
				?>
				<option value="<?php echo get_the_ID(); ?>"<?php echo $selected_indicator;?>><?php the_title(); ?></option>
				<?php endwhile;
				wp_reset_query();
			?>
			 </select>		
		  </p>		
		<?php       
	}
}
// register_widget('themique_power_shortcodes');
add_action('widgets_init', 'register_states_widget');
function register_states_widget() {
    register_widget('themique_power_shortcodes');
}
?>